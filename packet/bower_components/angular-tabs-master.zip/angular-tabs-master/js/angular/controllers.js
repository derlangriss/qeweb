'use strict';


angular
    .module( 'app', [ 'tabs' ])


    .controller( 'TestController', function() {

    });